// AddTask.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { ADD_TASK } from './actions';

const AddTask = () => {
  const [description, setDescription] = useState('');
  const dispatch = useDispatch();

  const handleAddTask = () => {
    if (description.trim() === '') return;
    const newTask = {
      id: Date.now(), // For simplicity, use the current timestamp as the ID. In production, use a unique ID generator.
      description: description,
      isDone: false,
    };
    dispatch({ type: ADD_TASK, payload: newTask });
    setDescription('');
  };

  return (
    <div>
      <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
      <button onClick={handleAddTask}>Add Task</button>
    </div>
  );
};

export default AddTask;
