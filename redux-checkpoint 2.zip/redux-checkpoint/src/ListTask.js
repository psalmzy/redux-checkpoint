// ListTask.js
import React from 'react';
import { useSelector } from 'react-redux';
import Task from './Task';

const ListTask = ({ showDone }) => {
  const tasks = useSelector((state) =>
    showDone ? state.tasks.filter((task) => task.isDone) : state.tasks.filter((task) => !task.isDone)
  );

  return (
    <div>
      <h2>{showDone ? 'Completed Tasks' : 'Pending Tasks'}</h2>
      {tasks.length === 0 ? <p>No tasks found.</p> : tasks.map((task) => <Task key={task.id} task={task} />)}
    </div>
  );
};

export default ListTask;
