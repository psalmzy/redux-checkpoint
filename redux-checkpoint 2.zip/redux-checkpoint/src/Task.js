// Task.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { EDIT_TASK, TOGGLE_TASK } from './actions';

const Task = ({ task }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedDescription, setEditedDescription] = useState(task.description);
  const dispatch = useDispatch();

  const handleEditTask = () => {
    setIsEditing(!isEditing);
    dispatch({ type: EDIT_TASK, payload: { id: task.id, description: editedDescription } });
    setIsEditing(false);
  };

  const handleToggleTask = () => {
    dispatch({ type: TOGGLE_TASK, payload: { id: task.id } });
  };

  return (
    <div>
      {isEditing ? (
        <input type="text" value={editedDescription} onChange={(e) => setEditedDescription(e.target.value)} />
      ) : (
        <span style={{ textDecoration: task.isDone ? 'line-through' : 'none' }}>{task.description}</span>
      )}
      <button onClick={handleEditTask}>{isEditing ? 'Save' : 'Edit'}</button>
      <button onClick={handleToggleTask}>{task.isDone ? 'Undo' : 'Done'}</button>
    </div>
  );
};

export default Task;
